import UIKit

struct personal
{
    var employeeID: Int
    var name: String
    var country: String
    var address: String
    var hobbies: String?

}

struct professional
{
    var employeeID: Int
    var name: String
    var department: String
    var branch: String
    var experience: Int

}

struct Employee
{
    var employeeID: Int
    var name: String
    var country: String
    var address: String
    var hobbies: String?
    var department: String
    var branch: String
    var experience: Int
}

var per_array: [personal] = [personal(employeeID: 1, name: "Shreyansh", country: "india", address: "delhi", hobbies: "chess"),
personal(employeeID: 2, name: "Shashank", country: "japan", address: "noida"), personal(employeeID: 3, name: "prince", country: "china", address: "modinagar", hobbies: "sleeping"), personal(employeeID: 4, name: "seth", country: "britain", address: "inlungwa", hobbies: "english"), personal(employeeID: 5, name: "saurav", country: "america", address: "merrut")]


var pro_array: [professional] = [professional(employeeID: 1, name: "shreyansh", department: "ios", branch: "cse", experience: 1), professional(employeeID: 2, name: "shashank", department: "android", branch: "cse", experience: 2), professional(employeeID: 4, name: "seth", department: "inlungwa", branch: "it", experience: 5)]


var sizeOfPer = per_array.endIndex - 1
var sizeOfPro = pro_array.endIndex - 1

var employee = [Employee]()

//que 1 -> create a third employee structure that contains the information from both based on common id.


for i in 0...sizeOfPer{
    for j in 0...sizeOfPro{
        if(per_array[i].employeeID == pro_array[j].employeeID)
        {
            employee.append(Employee(employeeID: per_array[i].employeeID, name: per_array[i].name, country: per_array[i].country, address: per_array[i].address, hobbies: per_array[i].hobbies, department: pro_array[j].department, branch: pro_array[j].branch, experience: pro_array[j].experience))
        }
    }
}

//que 2 -> write a function that takes the two structure and give me list of all the employee that live in certain country


func sameCountry(fisrt: [personal], sec: [professional])
{
    for i in 0...sizeOfPer
    {
        for j in 0...sizeOfPro
        {
            if(fisrt[i].country == "india" && fisrt[i].employeeID == sec[j].employeeID)
            {
                print(fisrt[i])
                print(sec[j])
                
            }
            
        }
    }
}

sameCountry(fisrt: per_array, sec: pro_array)

//que 3 -> write a function that give me list of all the employee that live in certain department


func sameDept(fisrt: [personal], sec: [professional])
{
    for i in 0...sizeOfPer
    {
        for j in 0...sizeOfPro
        {
            if(sec[j].department == "ios" && fisrt[i].employeeID == sec[j].employeeID)
            {
                print(fisrt[i])
                print(sec[j])
                
            }
            
        }
    }
}

sameDept(fisrt: per_array, sec: pro_array)



//que 4 -> write a function that give me list of all the employee that live in same country and work in the same branch.

var sizeOfEmp = employee.endIndex - 1

func same(first: [personal], sec: [professional])
{
    for i in 0...sizeOfPer
    {
        for j in 0...sizeOfPro
        {
            if(first[i].country == "india" && sec[j].branch == "cse" && first[i].employeeID == sec[j].employeeID)
            {
                print(first[i])
                print(sec[j])
                
            }
            
        }
    }
}

same(first: per_array, sec: pro_array)


//que 5 -> write a function that return me list of all the employee name that has a hobby and with their experience

func showHobbyExp(First: [personal], sec: [professional])
{
    for i in 0...sizeOfPer{
        for j in 0...sizeOfPro
        {
            if(First[i].hobbies != nil && sec[j].experience > 0 && First[i].employeeID == sec[j].employeeID )
            {
                print(First[i])
                print(sec[j])
            }
        }
    }
}

showHobbyExp(First: per_array, sec: pro_array)


//que 6 -> write a function that return me list of all the employee name that starts with any “S”

//func showWithS(First: [personal], sec: [professional])
//{
//    for i in 0...sizeOfPer{
//        for j in 0...sizeOfPro
//        {
//            if(First[i].name[0] == "s" && First[i].employeeID == sec[j].employeeID )
//            {
//                print(First[i])
//                print(sec[j])
//            }
//        }
//    }
//}
//

